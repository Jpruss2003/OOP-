/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cs1760spring.assignment1;

/**
 *
 * @author juliuspruss
 */
//For step 4 !!
public class TestExceptions {
    public static void main(String[] args){
        try{
            getExceptionB();
        }catch(ExceptionA e){
            System.out.println("A caught b");
        }
        try{
            getExceptionC();
        }catch(ExceptionA e){
            System.out.println("A caught C");
        }
        
        
        
        
        
        
        
        
        
    }
    public static void getExceptionB() throws ExceptionB{
        throw new ExceptionB("B exception");
    }
    
    public static void getExceptionC() throws ExceptionC{
        throw new ExceptionC("C exception");
    }
}
