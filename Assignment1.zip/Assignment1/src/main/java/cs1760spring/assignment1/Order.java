/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cs1760spring.assignment1;

/**
 *
 * @author juliuspruss
 */
public class Order {
    public static void main(String[] args){
        try{
            int s = 10/0;
            System.out.println("Result: " + s);
        }
        catch(Exception exception){
            System.out.println("Random Exception handled");
        }
        //will generate the failed exception and cannot reach it just undo parenthesis
        //catch(ArithmeticException exception){
         //   System.out.println("Error will not work");
       // }
     
    }
}
