/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cs1760spring.assignment1;

import java.io.IOException;

/**
 *
 * @author juliuspruss
 */
public class ExceptionCatcher {
    public static void main(String[] args) throws IOException{
        try{
            throw new ExceptionA1();
        }catch(Exception exceptiona){
            System.out.println("Caught exception A: " + exceptiona.getMessage());
        }
        
        try{
            throw new ExceptionB1();
        }catch(Exception exceptionb){
            System.out.println("Caught exception B: " + exceptionb.getMessage());
        }
            
        try{
            String pointer = null;
            System.out.println(pointer.length());
        }catch(NullPointerException exceptionP){
            System.out.println("Caught NULL pointer exception");
        }
        
        try{
            throw new IOException();
        }catch(IOException exceptionI){
            System.out.println("Caught IO exception");
        }
    }
}
