/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cs1760spring.assignment1;

import java.util.ArrayList;
import java.util.List;



/**
 *
 * @author juliuspruss
 */
public class OutofMemory {
    public static void main(String[] args){
       List<Integer> list = new ArrayList<>();
        try{
            int i = 0;
            while(true){
                list.add(i++);
            }
        }catch(OutOfMemoryError e){
            System.out.println("Handled OutOfMemoryError....");
        }
    }
       
}
