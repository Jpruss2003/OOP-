/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cs1760spring.assignment1;

/**
 *
 * @author juliuspruss
 */
//this is for step 4 !!
public class ExceptionC extends ExceptionB {
    
    public ExceptionC(String message) {
        super(message);
    }
    
}
