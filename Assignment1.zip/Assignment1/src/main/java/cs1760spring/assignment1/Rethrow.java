/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cs1760spring.assignment1;

/**
 *
 * @author juliuspruss
 */
public class Rethrow {
    public static void main(String[] args){
        try{
            someMethod();
        }catch(Exception e){
            System.err.println("error, already caught in main: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void someMethod() throws Exception{
        try{
            someMethod2();
        }catch(Exception exception){
            System.err.println("Caught Exception and rethrowing");
            throw new Exception("Rethrowing exception that was caught", exception);
        }
    }
    
    public static void someMethod2() throws Exception{
        throw new Exception("Error");
    }

}
