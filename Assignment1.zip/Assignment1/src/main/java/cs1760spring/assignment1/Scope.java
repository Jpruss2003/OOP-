/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cs1760spring.assignment1;
/**
 *
 * @author juliuspruss
 */
public class Scope {
    public static void main(String[] args){
        try{
            someMethod();
        }catch(ArithmeticException e){
            System.out.println("Error, cannot divide by 0, error in main" + e.getMessage());

        }catch(NullPointerException p){
            System.out.println("Null string, error in main" + p.getMessage());
        }
        catch(Exception e){
           System.out.println("will not print, error by someMethod" + e.getMessage());
        }

    }
        
    
    public static void someMethod(){
        try{
            int s = 2/0;
            System.out.println("result" + s);
        }finally{
            System.out.println("Will not catch this, will give error in main");
        }
        
        try{
            String pointer = null;
            System.out.println(pointer.length());
        }finally {
            System.out.println("Caught NULL pointer exception will not be caught");
        
        }
    }
}
