package com.example.assignment2part2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
public class Assign2DrawController {

    @FXML
    private RadioButton lineRadio, circleRadio, rectangleRadio;
    @FXML
    private TextField x1Field, y1Field, x2Field, y2Field, radiusField, widthField, heightField;
    @FXML
    private Label x1Label, y1Label, x2Label, y2Label, radiusLabel, widthLabel, heightLabel;
    @FXML
    private ColorPicker colorPicker;
    @FXML
    private ComboBox<String> shadingComboBox;
    @FXML
    private TextField errorTextField;
    @FXML
    private Canvas canvas;

    private GraphicsContext gc;

    private String shapeType = "Line";
    private Color selectedColor = Color.BLACK;
    private String shadingType = "Full";

    @FXML
    public void initialize() {
        gc = canvas.getGraphicsContext2D();
        ToggleGroup shapeGroup = new ToggleGroup();
        lineRadio.setToggleGroup(shapeGroup);
        circleRadio.setToggleGroup(shapeGroup);
        rectangleRadio.setToggleGroup(shapeGroup);
        lineRadio.setSelected(true);

        shadingComboBox.getItems().addAll("Full", "Light", "Empty");
        shadingComboBox.setValue("Full");

        updateFields("Line");
    }

    @FXML
    private void handleRadioAction(ActionEvent event) {
        if (event.getSource() == lineRadio) {
            updateFields("Line");
        } else if (event.getSource() == circleRadio) {
            updateFields("Circle");
        } else if (event.getSource() == rectangleRadio) {
            updateFields("Rectangle");
        }
    }

    @FXML
    private void handleColorAction(ActionEvent event) {
        selectedColor = colorPicker.getValue();
    }

    @FXML
    private void handleShadingAction(ActionEvent event) {
        shadingType = shadingComboBox.getValue();
    }

    @FXML
    private void handleDrawAction(ActionEvent event) {
        drawShape();
    }

    private void updateFields(String shape) {
        shapeType = shape;
        if (shape.equals("Line")) {
            x1Label.setVisible(true);
            x1Field.setVisible(true);
            y1Label.setVisible(true);
            y1Field.setVisible(true);
            x2Label.setVisible(true);
            x2Field.setVisible(true);
            y2Label.setVisible(true);
            y2Field.setVisible(true);
            radiusLabel.setVisible(false);
            radiusField.setVisible(false);
            widthLabel.setVisible(false);
            widthField.setVisible(false);
            heightLabel.setVisible(false);
            heightField.setVisible(false);
        } else if (shape.equals("Circle")) {
            x1Label.setText("CenterX:");
            y1Label.setText("CenterY:");
            x1Label.setVisible(true);
            x1Field.setVisible(true);
            y1Label.setVisible(true);
            y1Field.setVisible(true);
            radiusLabel.setVisible(true);
            radiusField.setVisible(true);
            x2Label.setVisible(false);
            x2Field.setVisible(false);
            y2Label.setVisible(false);
            y2Field.setVisible(false);
            widthLabel.setVisible(false);
            widthField.setVisible(false);
            heightLabel.setVisible(false);
            heightField.setVisible(false);
        } else if (shape.equals("Rectangle")) {
            x1Label.setText("TopLeftX:");
            y1Label.setText("TopLeftY:");
            x1Label.setVisible(true);
            x1Field.setVisible(true);
            y1Label.setVisible(true);
            y1Field.setVisible(true);
            widthLabel.setVisible(true);
            widthField.setVisible(true);
            heightLabel.setVisible(true);
            heightField.setVisible(true);
            x2Label.setVisible(false);
            x2Field.setVisible(false);
            y2Label.setVisible(false);
            y2Field.setVisible(false);
            radiusLabel.setVisible(false);
            radiusField.setVisible(false);
        }
    }

    private void drawShape() {
        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        gc.setStroke(selectedColor);
        gc.setFill(selectedColor);

        try {
            if (shapeType.equals("Line")) {
                double x1 = Double.parseDouble(x1Field.getText());
                double y1 = Double.parseDouble(y1Field.getText());
                double x2 = Double.parseDouble(x2Field.getText());
                double y2 = Double.parseDouble(y2Field.getText());
                gc.strokeLine(x1, y1, x2, y2);
            } else if (shapeType.equals("Circle")) {
                double centerX = Double.parseDouble(x1Field.getText());
                double centerY = Double.parseDouble(y1Field.getText());
                double radius = Double.parseDouble(radiusField.getText());

                if (shadingType.equals("Full")) {
                    gc.fillOval(centerX - radius, centerY - radius, 2 * radius, 2 * radius);
                } else if (shadingType.equals("Light")) {
                    gc.setFill(selectedColor.deriveColor(0, 1, 1, 0.5));
                    gc.fillOval(centerX - radius, centerY - radius, 2 * radius, 2 * radius);
                } else {
                    gc.strokeOval(centerX - radius, centerY - radius, 2 * radius, 2 * radius);
                }
            } else if (shapeType.equals("Rectangle")) {
                double x = Double.parseDouble(x1Field.getText());
                double y = Double.parseDouble(y1Field.getText());
                double width = Double.parseDouble(widthField.getText());
                double height = Double.parseDouble(heightField.getText());

                if (shadingType.equals("Full")) {
                    gc.fillRect(x, y, width, height);
                } else if (shadingType.equals("Light")) {
                    gc.setFill(selectedColor.deriveColor(0, 1, 1, 0.5));
                    gc.fillRect(x, y, width, height);
                } else {
                    gc.strokeRect(x, y, width, height);
                }
            }
            errorTextField.setText(""); // Clear error message
        } catch (NumberFormatException e) {
            errorTextField.setText("Invalid input. Please enter numbers.");
        }
    }
}

