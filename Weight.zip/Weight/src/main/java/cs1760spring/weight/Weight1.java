/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cs1760spring.weight;
/**
 *
 * @author juliuspruss
 */
public class Weight1 extends Weight implements Comparable<Weight> {
    private int tons;
    private int pounds;
    
    public Weight1(){
       this.tons = 0;
       this.pounds = 0;
    }
    
    public Weight1(int t, int p){
        this.tons = t;
        this.pounds = p;
    }
    
    public Weight1(Weight1 w){
       this.tons = w.tons;
       this.pounds = w.pounds;
    }
    
    public void setPounds(int p){
       this.pounds = p;
    }
    
    public void setTons(int t){
        this.tons = t;
    }
    
    public int getPounds(){
        return pounds;
    }
    
    public int getTons(){
        return tons;
    }
    
    public Weight1 add(Weight1 w){
       int newTons = this.getTons() + w.getTons();
       int newPounds = this.getPounds() + w.getPounds();
       Weight1 newWeight1 = new Weight1(newTons, newPounds);
       newWeight1.convert();
       return newWeight1;
    }
    
    public Weight1 subtract(Weight1 w){
        int newTons = this.getTons() - w.getTons();
        int newPounds = this.getPounds() - w.getPounds();
        Weight1 newWeight1 = new Weight1(newTons, newPounds);
        newWeight1.convert();
        return newWeight1;
    }
    
    @Override
    public int toOunces(){
       int newPounds = this.pounds + 2000*tons;
       int newOunces = newPounds*16;
       
       return newOunces;
    }
    
    
    @Override
    public void convert(){
        if(this.pounds > 0){
            this.tons += this.pounds / 2000;
            this.pounds %= 2000;
        }
        else if(this.pounds < 0 || getPounds() < 0){
            this.tons -= 1;
            this.pounds = 0;
        }
        if(this.tons < 0){
            this.tons = 0;
        }
    }

    
    @Override
    public String toString(){
        return("Tons: " + this.tons + " Pounds: " + this.pounds);
    }
    
    public int compareTo(Weight1 w){
        //tons first then pounnds
        if(this.tons < w.tons){
            return -1;
        } 
        else if(this.tons == w.tons){
            return 0;    
        }
        else if(this.tons > w.tons){
            return 1;
        }
        if(this.pounds < w.pounds){
            return -1;    
        }
        else if(this.pounds == w.pounds){
            return 0;
        }
        else if(this.pounds > w.pounds){
            return -1;
        }
        
    return 0;
 }
}
