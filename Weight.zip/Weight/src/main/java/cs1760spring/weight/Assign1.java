/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cs1760spring.weight;

import java.util.Arrays;

/**
 *
 * @author juliuspruss
 */
public class Assign1 {
    public static void main(String[] args){
        Weight1 a = new Weight1(67, 1901);
        Weight1 b = new Weight1(10, 1984);
        Weight1 c = new Weight1();
        Weight1 d = new Weight1();
        Weight1 e = new Weight1();
        Weight1 f = new Weight1();
        Weight1 g = new Weight1();
        Weight1 h = new Weight1();
        
        Weight2 w = new Weight2(57, 888, 10);
        Weight2 x = new Weight2(56, 1913, 14);
        Weight2 y = new Weight2();
        Weight2 z = new Weight2();
        
        c = a.add(b);
        d = a.subtract(b);
        y = w.add(x);
        z = w.subtract(x);
        e = a.add(w);
        f = a.subtract(w);
        g = x.add(b);
        h = x.subtract(b);
        
        Weight[] arr = new Weight[] {a,b,c,d,e,f,g,h,w,x,y,z};
        System.out.println("Before sort: ");
        for(Weight weight : arr){
            System.out.println(weight);
        }
        Arrays.sort(arr);
        
        System.out.println("Sorted array: ");
        for(Weight weight : arr){
            System.out.println(weight);
        }
        
        System.out.println("Compare b to x: " + b.compareTo(x));
        System.out.println("compare x to b: " + x.compareTo(b));
        
        System.out.println("A to ounces: " + a.toOunces());
        System.out.println("w in ounces: " + w.toOunces());
        
        
        
    }
}
