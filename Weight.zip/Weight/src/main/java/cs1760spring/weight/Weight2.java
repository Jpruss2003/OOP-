/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cs1760spring.weight;

/**
 *
 * @author juliuspruss
 */
public class Weight2 extends Weight1 {
    private int ounces;
    
    
    public Weight2(){
        this.ounces = 0;
    }
    
    public Weight2(int t, int p, int oz){
        setTons(t);
        setPounds(p);
        this.ounces = oz;
    }
    
    public Weight2(Weight2 w){
        this.ounces = w.ounces;
    }
    
    public void setOunces(int oz){
        this.ounces = oz;
    }
    
    public int getOunces(){
        return ounces;
    }
    
    public Weight2 add(Weight2 w){
       int newTons = this.getTons() + w.getTons();
       int newPounds = this.getPounds() + w.getPounds();
       int newOunces = this.getOunces() + w.getOunces();
       Weight2 newWeight2 = new Weight2(newTons, newPounds, newOunces);
       newWeight2.convert();
       return newWeight2;
    }
    
    public Weight2 subtract(Weight2 w){
        int newTons = this.getTons() - w.getTons();
        int newPounds = this.getPounds() - w.getPounds();
        int newOunces = this.getOunces() - w.getOunces();
        Weight2 newWeight2 = new Weight2(newTons, newPounds, newOunces);
        newWeight2.convert();
        return newWeight2;
    }
    
    @Override
    public int toOunces(){
       int newPounds = this.getPounds() + 2000*getTons();
       int newOunces = newPounds*16;
       
       return newOunces;
    }
    
    @Override
    public void convert(){
        if(this.getPounds() > 0){
            this.setTons(this.getTons() + this.getPounds() / 2000);
            this.setPounds(this.getPounds() % 2000);
        }
        else if(this.getPounds() < 0 || getPounds() < 0){
            this.setTons(-1);
            this.setPounds(0);
        }
        if(this.getTons() < 0){
            this.setTons(0);
        }
    }
    
    @Override
    public String toString(){
        return("Tons: " + getTons() + " Pounds: " + getPounds() + " Ounces: " + this.ounces);
    }
    
    @Override
    public int compareTo(Weight1 w){
        
        //tons first then pounnds
        if(this.getTons() < w.getTons()){
            return -1;
        } 
        else if(this.getTons() == w.getTons()){
            return 0;    
        }
        else if(this.getTons() > w.getTons()){
            return 1;
        }
        if(this.getPounds() < w.getPounds()){
            return -1;    
        }
        else if(this.getPounds() == w.getPounds()){
            return 0;
        }
        else if(this.getPounds() > w.getPounds()){
            return -1;
        }
        
    return 0;
    }
}

