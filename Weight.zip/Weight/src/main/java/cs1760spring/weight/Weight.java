/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package cs1760spring.weight;

/**
 *
 * @author juliuspruss
 */
public abstract class Weight implements Comparable<Weight> {

    public abstract int toOunces();
    public abstract void convert();
    @Override
    public int compareTo(Weight other) {
        return Integer.compare(this.toOunces(), other.toOunces());
    }
    
 }


