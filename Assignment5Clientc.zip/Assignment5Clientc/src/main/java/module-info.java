module com.example.assignment5clientc {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.assignment5clientc to javafx.fxml;
    exports com.example.assignment5clientc;
}