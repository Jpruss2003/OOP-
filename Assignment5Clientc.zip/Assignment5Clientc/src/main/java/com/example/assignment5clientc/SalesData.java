package com.example.assignment5clientc;

import java.io.Serializable;
import java.io.Serial;
import java.io.Serializable;

public class SalesData implements Serializable {
        private static final long serialVersionUID = 1L;
        private final int salesID;
        private final String salesRep;
        private String place;
        private double amount;

        public SalesData(int salesID, String salesRep, String place, double amount){
            this.salesID = salesID;
            this.salesRep = salesRep;
            this.place = place;
            this.amount = amount;
        }

        public int getSalesID(){
            return salesID;
        }

        public String getSalesRep(){
            return salesRep;
        }

        public String getPlace(){
            return place;
        }

        public double getAmount(){
            return amount;
        }

        public void setPlace(String place){
            this.place = place;
        }

        public void setAmount(double amount){
            this.amount = amount;
        }

        public String toString() {
            return ("Sales ID: " + salesID + "Sales Rep: " + salesRep + "Place: " + place +
                    "Amount: $" + amount);
        }
    }

