package com.example.assignment5clientc;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class ClientController {
    @FXML
    private TextArea messageArea;

    @FXML
    private TextField inputField;

    @FXML
    private Button connectButton;

    @FXML
    private Button addSaleButton;

    @FXML
    private Button viewMySalesButton;

    @FXML
    private Button viewAllSalesButton;

    @FXML
    private Button editSaleButton;

    @FXML
    private Button deleteSaleButton;

    @FXML
    private Button exitButton;

    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private String salesRep;
    private String serverAddress = "localhost";
    private int state = 0; // 0: initial, 1: adding sale, 2: editing sale, 3: deleting sale.
    private int editID = -1;
    private int deleteID = -1;

    @FXML
    public void initialize(){
        setButtons(true, false, false, false, false, false, false);
    }
    private void setButtons(boolean connect, boolean add, boolean viewMy, boolean viewAll, boolean edit, boolean delete, boolean exit){
        connectButton.setDisable(!connect);
        addSaleButton.setDisable(!add);
        viewMySalesButton.setDisable(!viewMy);
        viewAllSalesButton.setDisable(!viewAll);
        editSaleButton.setDisable(!edit);
        deleteSaleButton.setDisable(!delete);
        exitButton.setDisable(!exit);
    }
    private void enableButtons(){
        setButtons(false, true, true, true, true, true, true);
    }
    @FXML
    private void connectButton() {
        try {
            socket = new Socket("localhost", 12345);
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());

            salesRep = inputField.getText();
            out.writeObject(salesRep);
            messageArea.appendText("Connected as: " + salesRep + "\n");

            enableButtons();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void addSalesButton(){
        try {
            out.writeObject("add_sale");
            messageArea.appendText("Enter the place of sale: \n");
            inputField.setOnAction(actionEvent -> {
                try {
                    String place = inputField.getText();
                    out.writeObject(place);
                    inputField.clear();
                    messageArea.appendText("Enter the amount of sale: \n");
                    inputField.setOnAction(actionEvent1 -> {
                        try {
                            Double amount = Double.parseDouble(inputField.getText());
                            out.writeObject(amount);
                            inputField.clear();
                            String response = (String) in.readObject();
                            messageArea.appendText(response + "\n");
                        } catch (IOException | ClassNotFoundException e) {
                            e.printStackTrace();
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void setViewMySalesButton(){
        try{
            out.writeObject("view_my_sales");
            ArrayList<SalesData> myList = (ArrayList<SalesData>) in.readObject();
            messageArea.clear();
            for(SalesData sale : myList){
                messageArea.appendText(sale.toString() + "\n");
            }
        }catch(IOException | ClassNotFoundException e){
            e.printStackTrace();
        }
    }

    @FXML
    public void viewAllSalesButton(){
        try{
            out.writeObject("view_all_sales");
            ArrayList<SalesData> allList = (ArrayList<SalesData>) in.readObject();
            messageArea.clear();
            for(SalesData sale : allList){
                messageArea.appendText(sale.toString() + "\n");
            }
        }catch(IOException | ClassNotFoundException e){
            e.printStackTrace();
        }
    }

    @FXML
    public void editSaleButton(){
        state = 2;
        messageArea.appendText("Enter the ID of the sale to edit: \n");
        inputField.setOnAction(actionEvent -> {
            try{
                editID = Integer.parseInt(inputField.getText());
                out.writeObject("edit_sale");
                out.writeObject(editID);
                inputField.clear();
                messageArea.appendText("Enter new place of sale: \n");
                inputField.setOnAction(actionEvent1 -> {
                    try{
                        String newPlace = inputField.getText();
                        out.writeObject(newPlace);
                        inputField.clear();
                        messageArea.appendText("Enter new amount of sale: \n");
                        inputField.setOnAction(actionEvent2 -> {
                            try{
                                double newAmount = Double.parseDouble(inputField.getText());
                                out.writeObject(newAmount);
                                inputField.clear();
                                String response = (String) in.readObject();
                                messageArea.appendText(response + "\n");
                                state = 0;
                                editID = -1;
                                inputField.setOnAction(null);
                            }catch(IOException | ClassNotFoundException e){
                                e.printStackTrace();
                            }
                        });
                    }catch(IOException e){
                        e.printStackTrace();
                    }
                });
            }catch(IOException e){
                e.printStackTrace();
            }
        });
    }

    @FXML
    public void deleteSaleButton(){
        state = 3;
        messageArea.appendText("Enter the ID of the sale to delete: \n");
        inputField.setOnAction(actionEvent -> {
            try{
                deleteID = Integer.parseInt(inputField.getText());
                out.writeObject("delete_sale");
                out.writeObject(deleteID);
                inputField.clear();
                String response = (String) in.readObject();
                messageArea.appendText(response + "\n");
                state = 0;
                deleteID = -1;
                inputField.setOnAction(null);
            }catch(IOException | ClassNotFoundException e){
                e.printStackTrace();
            }
        });
    }

    @FXML
    public void exitButton(){
        try{
            if(socket != null){
                out.writeObject("exit");
                socket.close();
                messageArea.appendText("Disconnected from server.\n");
                setButtons(true, false, false, false, false, false, false);
                inputField.clear();
            }
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
