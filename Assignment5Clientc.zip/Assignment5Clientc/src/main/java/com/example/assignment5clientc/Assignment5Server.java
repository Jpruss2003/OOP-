package com.example.assignment5clientc;
import java.io.*;
import java.net.*;
import java.util.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Assignment5Server {
    private static ArrayList<SalesData> salesList = new ArrayList<>();
    private static int salesCounter = 1;

        public static void main(String[] args) {
            try (ServerSocket serverSocket = new ServerSocket(12234)) {
                System.out.println("Server started. Awaiting clients...");

                while (true) {
                    Socket clientSocket = serverSocket.accept();
                    System.out.println("New client connected: " + clientSocket);

                    ClientHandler clientHandler = new ClientHandler(clientSocket);
                    new Thread(clientHandler).start();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


        private static class ClientHandler implements Runnable {
            private Socket clientSocket;
            private ObjectInputStream in;
            private ObjectOutputStream out;
            private String salesRepName;

            public ClientHandler(Socket socket) {
                this.clientSocket = socket;
            }

            @Override
            public void run() {
                try {
                    out = new ObjectOutputStream(clientSocket.getOutputStream());
                    in = new ObjectInputStream(clientSocket.getInputStream());

                    salesRepName = (String) in.readObject();
                    System.out.println("Sales rep has logged in: " + salesRepName);

                    while (true) {

                        String message = (String) in.readObject();
                        switch (message) {
                            case "add_sale":
                                addSales();
                                break;
                            case "view_my_sales":
                                viewMySales();
                                break;
                            case "view_all_sales":
                                viewClientAllSales();
                                break;
                            case "edit_sales":
                                editSales();
                                break;
                            case "delete_sale":
                                deleteSale();
                                break;
                            case "exit":
                                System.out.println(salesRepName + "Logged out...");
                                return;
                        }
                    }
                } catch (IOException | ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        clientSocket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            private void addSales() throws IOException, ClassNotFoundException{
                String place = (String) in.readObject();
                double amount = Double.parseDouble((String) in.readObject());
                SalesData sale = new SalesData(salesCounter++, salesRepName, place, amount);
                salesList.add(sale);
                out.writeObject("Sale added with ID: " + sale.getSalesID());
            }

            private void viewMySales() throws IOException{
                ArrayList<SalesData> myList = new ArrayList<>();
                for (SalesData sale : salesList) {
                    if (sale.getSalesRep().equals(salesRepName)) {
                        myList.add(new SalesData(sale.getSalesID(), sale.getSalesRep(), sale.getPlace(), sale.getAmount()));
                    }
                }
                out.writeObject(myList);
            }

            private void viewClientAllSales() throws IOException{
                ArrayList<SalesData> myList = new ArrayList<>();
                for (SalesData sale : salesList) {
                    if (sale.getSalesRep().equals(salesRepName)) {
                        myList.add(new SalesData(sale.getSalesID(), sale.getSalesRep(), sale.getPlace(), sale.getAmount()));
                    }
                }
                out.writeObject(myList.toString());
            }

            private void editSales() throws IOException, ClassNotFoundException{
                out.writeObject("Enter sales ID to edit:");
                int editID = Integer.parseInt((String) in.readObject());
                SalesData editSale = null;
                for (SalesData sales : salesList) {
                    if (sales.getSalesID() == editID && sales.getSalesRep().equals(salesRepName)) {
                        editSale = sales;
                        break;
                    }
                }
                if (editSale != null) {
                    out.writeObject("Enter new sales location:");
                    editSale.setPlace((String) in.readObject());
                    out.writeObject("Enter new sales amount:");
                    editSale.setAmount(Double.parseDouble((String) in.readObject()));
                    out.writeObject("Sale edited.");
                } else {
                    out.writeObject("Sale not found or not owned by you.");
                }
            }

            private void deleteSale() throws IOException, ClassNotFoundException{
                out.writeObject("Enter sales ID to delete:");
                int deleteID = Integer.parseInt((String) in.readObject());
                //will check to see if these are satisfied if not, it will not work
                salesList.removeIf(sale -> sale.getSalesID() == deleteID && sale.getSalesRep().equals(salesRepName));
                out.writeObject("Sale deleted.");
            }

        }


    }

